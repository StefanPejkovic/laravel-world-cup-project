<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://yt3.ggpht.com/6VfAToSR9ej8AF3wb5YBv01-sKWbKcTI9RZwzKmVyniszjS7T7Zca0z7HE7K__oIVrFdVMq8Ick=s176-c-k-c0x00ffffff-no-rj" width="200" alt="Laravel Boy Channel Logo"></a></p>

<h2>
World Cup project , real world laravel project 
</h2>

<a href="https://www.youtube.com/playlist?list=PL9uWUH07ltBjJTum9FLc-a-_EHRxm2yfy">Project Playlist</a>
<h3>
Thank you .
</h3>
